# BSCode

## What is this?
A worse version of VSCode\
Can run Python
