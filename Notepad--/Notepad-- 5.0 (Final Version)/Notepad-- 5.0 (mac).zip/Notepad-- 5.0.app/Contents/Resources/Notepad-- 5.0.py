from tkinter import *
from tkinter import ttk

def englishButtonCmd():
    global notepadWindow
    notepadWindow = Tk()
    notepadWindow.geometry('600x600')
    notepadWindow.title("Notepad--")
    style = ttk.Style(notepadWindow)
    notepadWindow.tk.call('source', 'Azure-ttk-theme-main/azure/azure.tcl')
    style.theme_use('azure')

    credit = ttk.Label(notepadWindow, text="Notepad-- 5.0, © Bot Master 2021")
    credit.config(font=('*', 15))
    credit.pack()

    text_input = Text(notepadWindow, bg='#F7F7F7', fg='black')
    text_input.pack()

    buttonFrame = Frame(notepadWindow)
    buttonFrame.pack()

    global output
    output = Label()
    def printfunc():
        global output
        output.destroy()
        text_input_text = text_input.get("1.0",END)
        output = Label(notepadWindow, text=text_input_text)
        output.pack()

    def clearfunc():
        global output
        output.destroy()

    printButton = ttk.Button(buttonFrame, text='print', command=printfunc)
    printButton.pack(side=LEFT)
    Label(buttonFrame).pack(side=LEFT)
    clearButton = ttk.Button(buttonFrame, text='clear', command=clearfunc)
    clearButton.pack(side=LEFT)

    notepadWindow.protocol("WM_DELETE_WINDOW", closeWindow)
    notepadWindow.mainloop()

def frenchButtonCmd():
    global notepadWindow
    notepadWindow = Tk()
    notepadWindow.geometry('600x600')
    notepadWindow.title("Bloc-Notes--")
    style = ttk.Style(notepadWindow)
    notepadWindow.tk.call('source', 'Azure-ttk-theme-main/azure/azure.tcl')
    style.theme_use('azure')

    credit = ttk.Label(notepadWindow, text="Bloc-Notes-- 5.0, © Maître de Bot 2021")
    credit.config(font=('*', 15))
    credit.pack()

    text_input = Text(notepadWindow, bg='#F7F7F7', fg='black')
    text_input.pack()

    buttonFrame = Frame(notepadWindow)
    buttonFrame.pack()

    global output
    output = Label()
    def printfunc():
        global output
        output.destroy()
        text_input_text = text_input.get("1.0",END)
        output = Label(notepadWindow, text=text_input_text)
        output.pack()

    def clearfunc():
        global output
        output.destroy()

    printButton = ttk.Button(buttonFrame, text='imprimer', command=printfunc)
    printButton.pack(side=LEFT)
    Label(buttonFrame).pack(side=LEFT)
    clearButton = ttk.Button(buttonFrame, text='éliminer', command=clearfunc)
    clearButton.pack(side=LEFT)

    notepadWindow.protocol("WM_DELETE_WINDOW", closeWindow)
    notepadWindow.mainloop()

def closeWindow():
    global notepadWindow
    notepadWindow.destroy()
    langWindow()

def openEngWindow():
    root.destroy()
    englishButtonCmd()

def openFrWindow():
    root.destroy()
    frenchButtonCmd()

def langWindow():
    global root
    root = Tk()
    style = ttk.Style(root)
    root.tk.call('source', 'Azure-ttk-theme-main/azure/azure.tcl')
    style.theme_use('azure')
    root.geometry('340x140')
    root.title("Choose language/Choisissez une langue")

    Label(root).pack()
    englishButton = ttk.Button(root, text='English', style='Accentbutton', command=openEngWindow)
    englishButton.pack()
    Label(root).pack()
    frenchButton = ttk.Button(root, text='Français', style='Accentbutton', command=openFrWindow)
    frenchButton.pack()
    root.mainloop()

langWindow()