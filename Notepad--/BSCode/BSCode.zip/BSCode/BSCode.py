from tkinter import *
from tkinter import ttk
from tkinter import filedialog
import subprocess
from pynput.keyboard import Key, Controller

root = Tk()
keyboard = Controller()
root.winfo_screenheight()
root.winfo_screenwidth()
root.title("BSCode")
style = ttk.Style(root)
root.tk.call('source', 'theme/azure.tcl')
style.theme_use('azure')

f = open("output.txt", "w")
f.write("")
f.close()

credit = ttk.Label(root, text="BSCode   © Bot Master 2021")
credit.config(font=('*', 15))
credit.pack()

text_input = Text(root, bg='#666666', fg='#F7F7F7', width=200, height=40)
text_input.configure(font=("Courier", 12))
text_input.pack()

buttonFrame = Frame(root)
buttonFrame.pack()

output = Label()

OutputLabel = Label()

def on_press(key):
    if key.keysym == 'parenleft':
        keyboard.press(')')
        keyboard.press(Key.left)
        keyboard.release(')')
        keyboard.release(Key.left)
    if key.keysym == 'colon':
        keyboard.press(Key.enter)
        keyboard.press(' ')
        keyboard.press(' ')
        keyboard.press(' ')
        keyboard.press(' ')
        keyboard.release(Key.enter)
        keyboard.release(' ')
        keyboard.release(' ')
        keyboard.release(' ')
        keyboard.release(' ')

def openFile():
    global pyFile
    pyFile = filedialog.askopenfilename(filetypes=[("Python files", ".py")])
    return pyFile

def newFile():
    def newFileSaveFunc():
        global pyFile, fileChosen
        newFileName.destroy()
        pyExtensionLabel.destroy()
        newFileSave.destroy()
        FileName = str(fileName.get() + ".py")
        fileWrite = open(FileName, "w")
        fileChosen = True
        pyFile = FileName
    fileName = StringVar()
    newFileName = ttk.Entry(buttonFrame, textvariable=fileName)
    newFileName.pack(side=LEFT)
    pyExtensionLabel = Label(buttonFrame, text=".py")
    pyExtensionLabel.pack(side=LEFT)
    newFileSave = ttk.Button(buttonFrame, text="Save", command=newFileSaveFunc)
    newFileSave.pack(side=LEFT)


def runfunc(pyFile):
    clearshell()
    global OutputLabel
    text_input_text = text_input.get("1.0",END)
    f = open(pyFile, "w")
    f.write(text_input_text)
    f.close()
    try:
        subprocess.call(["python3", pyFile])
    except:
        subprocess.call(["python", pyFile])
    #Get console output here
    with open("output.txt", "w") as output:
        subprocess.call(["python3", pyFile], stdout=output)
    output = open("output.txt", "r")
    outputstr = output.read()
    OutputLabel.destroy()
    OutputLabel = Label(consoleFrame, text=outputstr, bg="#666666")
    OutputLabel.config(font=("Courier", 12))
    OutputLabel.pack(side=LEFT)

fileChosen = False
def runButtonFunc():
    global pyFile, fileChosen
    if fileChosen == False:
        runfunc(openFile())
        fileChosen = True
    elif fileChosen == True:
        runfunc(pyFile)

def clearshell():
    if fileChosen == False:
        def okButtonFunc():
            errorWindow.destroy()
        errorWindow = Toplevel()
        errorWindow.geometry("270x100")
        errorLabel = Label(errorWindow, text="Error, no file selected")
        errorLabel.pack()
        okButton = ttk.Button(errorWindow, text="OK", command=okButtonFunc)
        okButton.pack()
    else:
        global OutputLabel, pyFile
        OutputLabel.destroy()
        f = open(pyFile, "w")
        f.write("")
        f.close()

def cleartext():
    if fileChosen == False:
        def okButtonFunc():
            errorWindow.destroy()
        errorWindow = Toplevel()
        errorWindow.geometry("270x100")
        errorLabel = Label(errorWindow, text="Error, no file selected")
        errorLabel.pack()
        okButton = ttk.Button(errorWindow, text="OK", command=okButtonFunc)
        okButton.pack()
    else:
        text_input.delete(1.0, END)


printButton = ttk.Button(buttonFrame, text='Run', command=runButtonFunc)
printButton.pack(side=LEFT)
Label(buttonFrame).pack(side=LEFT)
cleartextButton = ttk.Button(buttonFrame, text='Clear text', command=cleartext)
cleartextButton.pack(side=LEFT)
Label(buttonFrame).pack(side=LEFT)
clearshellButton = ttk.Button(buttonFrame, text='Stop/Clear shell', command=clearshell)
clearshellButton.pack(side=LEFT)
Label(buttonFrame).pack(side=LEFT)
Label(buttonFrame).pack(side=LEFT)
newPyButton = ttk.Button(buttonFrame, text='New .py file', command=newFile)
newPyButton.pack(side=LEFT)

consoleFrame = Frame(root, highlightthickness=1, highlightbackground='black', height=300, width=1350, bg="#666666")
consoleFrame.pack_propagate(FALSE)
consoleFrame.pack()
Label(root).pack()

root.bind('<KeyPress>', on_press)

def on_closing():
    global pyFile
    f = open(pyFile, "w")
    f.write("")
    f.close()
    f = open("output.txt", "w")
    f.write("")
    f.close()
    quit()


root.protocol("WM_DELETE_WINDOW", on_closing)
root.mainloop()
