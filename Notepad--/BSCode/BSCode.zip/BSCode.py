from tkinter import *
from tkinter import ttk
import subprocess
from pynput.keyboard import Key, Controller


root = Tk()
keyboard = Controller()
root.winfo_screenheight()
root.winfo_screenwidth()
root.title("BSCode")
style = ttk.Style(root)
root.tk.call('source', 'Azure-ttk-theme-main/azure/azure.tcl')
style.theme_use('azure')

f = open("code.py", "w")
f.write("")
f.close()
f = open("output.txt", "w")
f.write("")
f.close()

credit = ttk.Label(root, text="BSCode   © Bot Master 2021")
credit.config(font=('*', 15))
credit.pack()

text_input = Text(root, bg='#F7F7F7', fg='#7D7D7D', width=200, height=40)
text_input.configure(font=("Courier", 12))
text_input.pack()

buttonFrame = Frame(root)
buttonFrame.pack()

output = Label()

OutputLabel = Label()

def on_press(key):
    if key.keysym == 'parenleft':
        keyboard.press(')')
        keyboard.press(Key.left)
        keyboard.release(')')
        keyboard.release(Key.left)
    if key.keysym == 'colon':
        keyboard.press(Key.enter)
        keyboard.press(' ')
        keyboard.press(' ')
        keyboard.press(' ')
        keyboard.press(' ')
        keyboard.release(Key.enter)
        keyboard.release(' ')
        keyboard.release(' ')
        keyboard.release(' ')
        keyboard.release(' ')


def runfunc():
    clearshell()
    global OutputLabel
    text_input_text = text_input.get("1.0",END)
    f = open("code.py", "w")
    f.write(text_input_text)
    f.close()
    try:
        subprocess.call(["python3", "code.py"])
    except:
        subprocess.call(["python", "code.py"])
    #Get console output here
    with open("output.txt", "w") as output:
        subprocess.call(["python3", "code.py"], stdout=output)
    output = open("output.txt", "r")
    outputstr = output.read()
    OutputLabel.destroy()
    OutputLabel = Label(consoleFrame, text=outputstr)
    OutputLabel.config(font=("Courier", 12))
    OutputLabel.pack(side=LEFT)


def clearshell():
    global OutputLabel
    OutputLabel.destroy()
    f = open("code.py", "w")
    f.write("")
    f.close()


def cleartext():
    text_input.delete(1.0, END)


printButton = ttk.Button(buttonFrame, text='run', command=runfunc)
printButton.pack(side=LEFT)
Label(buttonFrame).pack(side=LEFT)
cleartextButton = ttk.Button(buttonFrame, text='clear text', command=cleartext)
cleartextButton.pack(side=LEFT)
Label(buttonFrame).pack(side=LEFT)
clearshellButton = ttk.Button(buttonFrame, text='stop/clear shell', command=clearshell)
clearshellButton.pack(side=LEFT)

consoleFrame = Frame(root, highlightthickness=1, highlightbackground='black', height=300, width=1350)
consoleFrame.pack_propagate(FALSE)
consoleFrame.pack()
Label(root).pack()

root.bind('<KeyPress>', on_press)

def on_closing():
    f = open("code.py", "w")
    f.write("")
    f.close()
    f = open("output.txt", "w")
    f.write("")
    f.close()
    quit()


root.protocol("WM_DELETE_WINDOW", on_closing)
root.mainloop()