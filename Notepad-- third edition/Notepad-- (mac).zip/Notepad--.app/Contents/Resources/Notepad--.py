from tkinter import *

root = Tk()
root.geometry('600x600')
root.title("Notepad--")

credit = Label(root, text="Notepad-- third edition, © Bot Master 2021")
credit.config(font=('*', 15))
credit.pack()

text_input = Text(root, bg='gray', fg='white')
text_input.pack()

buttonFrame = Frame(root, bg='green')
buttonFrame.pack()

output = Label()
def printfunc():
    global output
    output.destroy()
    text_input_text = text_input.get("1.0",END)
    output = Label(root, text=text_input_text)
    output.pack()

def clearfunc():
    global output
    output.destroy()

clearButton = Button(buttonFrame, text='clear', command=printfunc)
clearButton.pack(side=LEFT)

printButton = Button(buttonFrame, text='print', command=clearfunc)
printButton.pack(side=LEFT)

def on_closing1():
    root = Tk()
    root.geometry('600x600')
    root.title("Notepad--")

    credit = Label(root, text="Notepad-- version 2.0, © Bot Master 2021")
    credit.config(font=('*', 15))
    credit.pack()

    text_input = Text(root, bg='gray', fg='white')
    text_input.pack()

    buttonFrame = Frame(root, bg='green')
    buttonFrame.pack()

    output = Label()

    def printfunc():
        global output
        output.destroy()
        text_input_text = text_input.get("1.0", END)
        output = Label(root, text=text_input_text)
        output.pack()

    def clearfunc():
        global output
        output.destroy()

    clearButton = Button(buttonFrame, text='clear', command=clearfunc)
    clearButton.pack(side=LEFT)

    printButton = Button(buttonFrame, text='print', command=printfunc)
    printButton.pack(side=LEFT)

    root.protocol("WM_DELETE_WINDOW", on_closing)

def on_closing():
    root = Tk()
    root.geometry('600x600')
    root.title("Notepad--")

    credit = Label(root, text="Notepad-- version 2.0, © Bot Master 2021")
    credit.config(font=('*', 15))
    credit.pack()

    text_input = Text(root, bg='gray', fg='white')
    text_input.pack()

    buttonFrame = Frame(root, bg='green')
    buttonFrame.pack()

    output = Label()

    def printfunc():
        global output
        output.destroy()
        text_input_text = text_input.get("1.0", END)
        output = Label(root, text=text_input_text)
        output.pack()

    def clearfunc():
        global output
        output.destroy()

    printButton = Button(buttonFrame, text='print', command=clearfunc)
    printButton.pack(side=LEFT)

    clearButton = Button(buttonFrame, text='clear', command=printfunc)
    clearButton.pack(side=LEFT)

    root.protocol("WM_DELETE_WINDOW", on_closing1)

root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()
